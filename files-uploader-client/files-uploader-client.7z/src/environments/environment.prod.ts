export const environment = {
  production: true,
  apiurl: "https://localhost:5001/api/v1/filesuploader"
};
