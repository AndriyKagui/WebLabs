export const ExtentionsConstants = {
  //Allowed file extentions (allows all types if empty) MIME type
  allowebExtentions: [],
  //file size in MB
  size: 50
}
