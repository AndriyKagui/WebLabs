export interface FileViewModel{
    name: string;
    uploadDate : Date;
    size: number;
    extention: string;
}
